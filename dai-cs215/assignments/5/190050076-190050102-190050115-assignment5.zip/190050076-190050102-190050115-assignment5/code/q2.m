clear; clc;

N = [5; 10; 20; 40; 60; 80; 100; 500; 1000; 10000];
M = 100;
lambda_true = 5;

errors = zeros(size(N,1), M, 2);

for n = 1:size(N,1)
    for m = 1:M
        X = rand(N(n),1);
        Y = (-1/lambda_true) * log(X);
        
        Y_sum = sum(Y);
        lambda_mle = N(n)/Y_sum;
        lambda_posteriorMean = (5.5+N(n)) / (1 + Y_sum);
        
        errors(n,m,1) = abs(lambda_mle-lambda_true)/lambda_true;
        errors(n,m,2) = abs(lambda_posteriorMean-lambda_true)/lambda_true;
    end
end

boxplot(errors(:,:,1)', N');
xlabel("N");
ylabel("Error");
title("Relative Error for MLE");
saveas(gcf, 'MLE_error', 'png');
pause(1);

boxplot(errors(:,:,2)', N');
xlabel("N");
ylabel("Error");
title("Relative Error for Posterior Mean Estimate");
saveas(gcf, 'PosteriorMeanEstimate_error', 'png');
pause(1);

close();