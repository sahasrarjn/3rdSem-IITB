rng(0);
mu = 10;
sigma  = 4;
M = 100;
Mu_mle = zeros(M,10);
Mu_map1 = zeros(M,10);
Mu_map2 = zeros(M,10);
N = [5, 10, 20, 40, 60, 80, 100, 500, 1000, 10000];
for n = 1:10
    mu_mle = zeros(M,1);
    mu_map1 = zeros(M,1);
    mu_map2 = zeros(M,1);
    for m = 1:M
        samp = randn(N(n),1)*sigma + mu;
        mu_mle(m) = sum(samp)/N(n);
        mu_map1(m) = (sum(samp) + 10.5*sigma^2)/(N(n) + sigma^2);
        if mu_mle(m) < 9.5
            mu_map2(m) = 9.5;
        elseif mu_mle(m) > 11.5
            mu_map2(m) = 11.5;
        else
            mu_map2(m) = mu_mle(m);
        end
        mu_mle(m) = abs(mu_mle(m)-mu)/mu;
        mu_map1(m) = abs(mu_map1(m)-mu)/mu;
        mu_map2(m) = abs(mu_map2(m)-mu)/mu;
        
    end
    Mu_mle(:,n) = mu_mle;
    Mu_map1(:,n) = mu_map1;
    Mu_map2(:,n) = mu_map2;
    
end

figure();
boxplot(Mu_mle,'Labels',{'5', '10', '20', '40', '60', '80', '100', '500', '1000', '10000'});
title('MLE');
ylabel('Relative Error in MLE estimation')
xlabel('N (No. of samples)')
saveas(gcf, 'Q1_1', 'png');
pause();
figure();
boxplot(Mu_map1,'Labels',{'5', '10', '20', '40', '60', '80', '100', '500', '1000', '10000'});
title('MAP1');
ylabel('Relative Error in MAP1 estimation')
xlabel('N (No. of samples)')
saveas(gcf, 'Q1_2', 'png');
pause();
figure();
boxplot(Mu_map2,'Labels',{'5', '10', '20', '40', '60', '80', '100', '500', '1000', '10000'});
title('MAP2');
ylabel('Relative Error in MAP2 estimation')
xlabel('N (No. of samples)')
saveas(gcf, 'Q1_3', 'png');
pause();
close();