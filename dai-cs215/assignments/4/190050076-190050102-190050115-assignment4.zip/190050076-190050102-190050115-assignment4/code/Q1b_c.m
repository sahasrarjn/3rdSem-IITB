N = 10;
estipi = zeros(9,1); %estipi is the array of the estimated pi values
for i = 1:9
    cnt = 0;
    if(N<=1e8)
        x1 = single(-1 + 2.*rand(1,N));
        x2 = single(-1 + 2.*rand(1,N));
        x = x1.^2 + x2.^2;
        cnt = sum(x<=1); %cnt is no. of points inside circle(x^2<=1 same as x<=1)
        estipi(i) = cnt*4/N;
    else
        part = int64(N/1e8);%deciding the no. of batches
        nleft = N-1e8*part;%remainder of the size divided by 1e8
        %for batches
        for j=1:part
            x1 = single(-1 + 2.*rand(1,1e8));
            x2 = single(-1 + 2.*rand(1,1e8));
            x = x1.^2 + x2.^2;
            cnt = cnt + sum(x<=1);
        end
        %for remaining
        if(nleft > 0)
            x1 = single(-1 + 2.*rand(1,nleft));
            x2 = single(-1 + 2.*rand(1,nleft));
            x = x1.^2 + x2.^2;
            cnt = cnt + sum(x<=1);
        end
        
 
        estipi(i) = cnt*4/N;
    end
    N = N*10;
end

estipi
