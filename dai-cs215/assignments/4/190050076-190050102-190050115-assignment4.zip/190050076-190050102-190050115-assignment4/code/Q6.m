clear; clc;

dinfo = dir('../data/data_fruit/*.png');
n = length(dinfo);
img = zeros(19200,n);

for k = 1 : length(dinfo)
 imgname = "../data/data_fruit/" + dinfo(k).name;
 imag = imread(imgname);
 sz = size(imag,1)*size(imag,2)*size(imag,3);
 img(:,k) = reshape(imag,[sz,1]); 
end

mu = sum(img,2)/n;

X = bsxfun(@minus, img, mu);
X = double(X);
C = X*X' / n;
[Q,D] = eigs(C); %eigenvalues and eigenvectors 
 %(Q,D from eigenvalue decomposition)
[~,ind] = sort(diag(D),'descend'); %sorting in order to implement PCA.
 

Ds = D(ind,ind);
Qs = Q(:,ind); %sorted matrices.
 

v = zeros(size(Qs,1),4,"double");
e = [0;0;0;0];
 
 

for i = 1:4
 v(:,i) = Qs(:,i);
 e(i) = Ds(i,i);
end
 
%first 10 eigenvalues;
 

d = eigs(C,10);
ab = 1:10;
figure();
plot(ab,d);
 

figure();
for i = 1:4
 subplot(2,3,i);
 image(rescale(reshape(v(:,i),[80,80,3])));
end
subplot(2,3,5);
image(rescale(reshape(mu,[80,80,3])))
 

Nimgs = v*v'*X + mu;


figure2=figure('Position', [100, 100, 200, 4000]);
%tiledlayout(16,2);
for i = 1:16
 subplot(16,2,2*i-1);
 image(rescale(reshape(img(:,i),[80,80,3])));
 subplot(16,2,2*i);
 image(rescale(reshape(Nimgs(:,i),[80,80,3]))); 
end
 


figure();
for i = 1:3
 y = randperm(16,3);
 y = y';
 Nimgs = sum(v*v'*X(:,y),2)/3 + mu;
 size(Nimgs)
 subplot(2,2,i);
 image(rescale(reshape(Nimgs,[80,80,3])));
end

