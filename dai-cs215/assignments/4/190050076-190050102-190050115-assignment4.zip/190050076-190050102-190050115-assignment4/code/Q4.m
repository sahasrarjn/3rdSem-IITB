clear; clc;
load("../data/mnist.mat");

tic
% digits = cat(3, digits_train, digits_test);
% labels = cat(1, labels_train, labels_test);
digits = digits_train;
labels = labels_train;
mean = cast(zeros(28*28,10), 'double');
covr = cast(zeros(28*28,28*28,10), 'double');

for i = 0:9
    X = [];
    cnt = 0;
    for d = 1:size(labels,1)
        if (labels(d) == i)
           X = cat(3, X, reshape(digits(:,:,d), [28*28,1]));
           cnt = cnt + 1;
        end
    end
    mean(:,i+1) = sum(X,3)/cnt;
    X = cast(X, 'double');
    dev = X - mean(:,i+1);
    dev = reshape(dev, [28*28,cnt]);
    covr(:,:,i+1) = dev*(dev')/(cnt-1);
end



% First mode of variation
mode = zeros(28*28,10);
eigenValues = zeros(28*28,10);
lambdas = zeros(1, 10);

for i = 1:10
    [ eig_vec, eig_mat ] = eig(covr(:,:,i));
    eigenValues(:,i) = sum(eig_mat)';
    lim = sum(eigenValues(:,i))/100;
    sum(eigenValues(:,i) > lim);
    [lambda, idx] = max(eigenValues(:,i));
    lambdas(:,i) = lambda;
    
    mode(:,i) =  eig_vec(:,idx); % Doubt: magnitude of mode of variance = 1??
end


% 2nd part
hold on
for i = 1:10
    figure1 = plot(sort(eigenValues(:,i), 'descend'));
end
title('Sorted Eigenvalues')
legend('0','1','2','3','4','5','6','7','8','9');
hold off
saveas(figure1, 'eigenValues', 'png');


% 3rd part
figure2=figure('Position', [100, 100, 1500, 1000]);
for i = 1:10
    left = mean(:,i) - sqrt(lambdas(:,i))*mode(:,i);
    mid = mean(:,i);
    right = mean(:,i) + sqrt(lambdas(:,i))*mode(:,i);
    
    subplot(5,6,3*i-2);
    imagesc(reshape(left, [28,28]));
    title('Mode 1');
    subplot(5,6,3*i-1);
    imagesc(reshape(mid, [28,28]));
    title('Mean');
    subplot(5,6,3*i);
    imagesc(reshape(right, [28,28]));
    title('Mode 2');
end
axis off
saveas(figure2, 'mode_of_variations', 'png');


time = toc;
disp(time);


time = toc;
disp(time);