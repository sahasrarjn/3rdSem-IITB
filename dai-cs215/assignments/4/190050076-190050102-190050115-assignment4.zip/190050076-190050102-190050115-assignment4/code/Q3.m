load("../data/points2D_Set1.mat",'x','y')
n = size(x,1);
mu = [sum(x)/n; sum(y)/n];
x1 = x - mu(1);      %bringing the mean to origin. (shifting origin)
y1 = y - mu(2);

C12 = sum(x1.*y1)./n;   % = C21 as Covariance matrix is symmetric.
C11 = sum(x1.^2)./n;
C22 = sum(y1.^2)./n;
C = [C11 C12; C12 C22];    %sample covariance matrix

[Q,D] = eig(C);          %eigenvalues and eigenvectors 
                         %(Q,D from eigenvalue decomposition)
[~,ind] = sort(diag(D),'descend');   %sorting in order to implement PCA.

% Ds = D(ind,ind);
Qs = Q(:,ind);            %sorted matrices.

%(v-\mu)'C(v-\mu) ..... to be maximised
%Qs'(v-\mu) = [1; 0] = u   (For maximum. Because Ds is sorted)
% v - \mu = Qs*u  (Qs is orthogonal)
% v = Qs*u + \mu

u = [1; 0];
v_minus_mu = Qs*u;  % the unit vector along the direction of the line
                    % in x-y plane that represents the approximate linear
                   %  relationship b/w x and y
figure();
scatter(x,y);
hold on;
X = [min(x):0.1*(max(x)-min(x)):max(x)];
Y = (v_minus_mu(2)/v_minus_mu(1))*(X-mu(1)) + mu(2);
plot(X,Y);

load("../data/points2D_Set2.mat",'x','y')
n = size(x,1);
mu = [sum(x)/n; sum(y)/n];
x1 = x - mu(1);      %bringing the mean to origin. (shifting origin)
y1 = y - mu(2);

C12 = sum(x1.*y1)./n;   % = C21 as Covariance matrix is symmetric.
C11 = sum(x1.^2)./n;
C22 = sum(y1.^2)./n;
C = [C11 C12; C12 C22];   %sample covariance matrix

[Q,D] = eig(C);          %eigenvalues and eigenvectors 
                         %(Q,D from eigenvalue decomposition)
[d,ind] = sort(diag(D),'descend');   %sorting in order to implement PCA.

Ds = D(ind,ind);
Qs = Q(:,ind);            %sorted matrices.

%(v-\mu)'C(v-\mu) ..... to be maximised
%Qs'(v-\mu) = [1; 0] = u   (For maximum. Because Ds is sorted)
% v - \mu = Qs*u  (Qs is orthogonal)
% v = Qs*u + \mu

u = [1; 0];
v_minus_mu = Qs*u;  % the unit vector along the direction of the line
                    % in x-y plane that represents the approximate linear
                   %  relationship b/w x and y
figure();
scatter(x,y);
hold on;
X = [min(x):0.1*(max(x)-min(x)):max(x)];
Y = (v_minus_mu(2)/v_minus_mu(1))*(X-mu(1)) + mu(2);
plot(X,Y);
ylim([-2,2]);