l = 10;
r = 1e9;
reqN = 1e9;
%binary search

while(l<r)
    m = floor((r+l)/2);
    probi = probability(m); %probability fn defined below
    if(probi<0.95)
        l = m+1;
    elseif(probi>0.95)
        r = m-1;
        reqN = m;
    else
        reqN = m;
        break;
    end
end

reqN

cnt = 0;

%calculating pi for the estimate sample size
if(reqN<=1e8)
    x1 = single(-1 + 2.*rand(1,reqN));
    x2 = single(-1 + 2.*rand(1,reqN));
    x = x1.^2 + x2.^2;
    cnt = sum(x<=1);
else
    part = int64(reqN/1e8);
    nleft = N-1e8*part
    for j=1:part
        x1 = single(-1 + 2.*rand(1,1e8));
        x2 = single(-1 + 2.*rand(1,1e8));
        x = x1.^2 + x2.^2;
        cnt = cnt + sum(x<=1);
    end
    if(nleft > 0)
        x1 = single(-1 + 2.*rand(1,nleft));
        x2 = single(-1 + 2.*rand(1,nleft));
        x = x1.^2 + x2.^2;
        cnt = cnt + sum(x<=1);
    end
end


estimatedpi = cnt*4/reqN;
estimatedpi

%function to calculate the probability at a sample size
function prob = probability(n)
    low = ceil(n*(pi-0.01)/4);
    high = floor(n*(pi+0.01)/4);
    prob = 0;
    for i=low:high
       prob = prob + exp(gammaln(n+1)-gammaln(i+1)-gammaln(n-i+1) + i*log(pi/4) + (n-i)*log(1-pi/4));
    end
end




