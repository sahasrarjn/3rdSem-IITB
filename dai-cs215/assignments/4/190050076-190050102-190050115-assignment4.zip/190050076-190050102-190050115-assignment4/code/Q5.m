clear; clc;
load("../data/mnist.mat");

tic
digits = cat(3, digits_train, digits_test);
labels = cat(1, labels_train, labels_test);
mean = cast(zeros(28*28,10), 'double');
covr = cast(zeros(28*28,28*28,10), 'double');

dataSize = size(labels,1);

for i = 0:9
    X = [];
    cnt = 0;
    for d = 1:dataSize
        if (labels(d) == i)
           X = cat(3, X, reshape(digits(:,:,d), [28*28,1]));
           cnt = cnt + 1;
        end
    end
    mean(:,i+1) = sum(X,3)/cnt;
    X = cast(X, 'double');
    dev = X - mean(:,i+1);
    dev = reshape(dev, [28*28,cnt]);
    covr(:,:,i+1) = dev*(dev')/(cnt-1);
end


% 84 max
coords = cast(zeros(84,28*28,10), 'double');
for i = 1:10
    coords(:,:,i) = coordinates(i,covr);
end

figure2=figure('Position', [100, 100, 1500, 1000]);
plot = 1;
for i = 0:9
    for j = 1:dataSize
        if(labels_train(j) == i)
            newImg = reconstruct(digits_train(:,:,j), coords(:,:,i+1), mean(:,i+1));
            
            subplot(5,4, plot); plot=plot+1;
            imagesc(digits_train(:,:,j));
            subplot(5,4, plot); plot=plot+1;
            imagesc(newImg);
            break;
        end
    end
end
saveas(figure2, 'reconstruct', 'png');



% fuction to return coordinates
function [coords] = coordinates(digit, covr)
    [ eig_vec, ~ ] = eigs(covr(:,:,digit), 84);
    coords = eig_vec';
end


% reconstruct image
function [new_img] = reconstruct(img, coord, mean)
    img = cast(img, 'double');
    img = reshape(img, [1, 28*28]);
    coord = coord';
    img = img - mean';
    score = img*coord;
    new_img = score*coord' + mean';
    new_img = reshape(new_img, [28,28]);
end

